YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "AlphaMapFilter",
        "AlphaMaskFilter",
        "Bitmap",
        "BitmapAnimation",
        "BoxBlurFilter",
        "ButtonHelper",
        "ColorFilter",
        "ColorMatrix",
        "ColorMatrixFilter",
        "Command",
        "Container",
        "DOMElement",
        "DisplayObject",
        "EaselJS",
        "EventDispatcher",
        "Filter",
        "Graphics",
        "Listener",
        "Log",
        "Matrix2D",
        "MouseEvent",
        "MovieClip",
        "MovieClipPlugin",
        "Point",
        "Rectangle",
        "Shadow",
        "Shape",
        "SpriteSheet",
        "SpriteSheetBuilder",
        "SpriteSheetUtils",
        "Stage",
        "Text",
        "Ticker",
        "Touch",
        "UID"
    ],
    "modules": [
        "EaselJS"
    ],
    "allModules": [
        {
            "displayName": "EaselJS",
            "name": "EaselJS",
            "description": "The EaselJS Javascript library provides a retained graphics mode for canvas\nincluding a full, hierarchical display list, a core interaction model, and\nhelper classes to make working with 2D graphics in Canvas much easier."
        }
    ]
} };
});