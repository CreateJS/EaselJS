YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "AlphaMapFilter",
        "AlphaMaskFilter",
        "Bitmap",
        "BitmapAnimation",
        "BitmapText",
        "BoxBlurFilter",
        "ButtonHelper",
        "ColorFilter",
        "ColorMatrix",
        "ColorMatrixFilter",
        "Command",
        "Container",
        "DOMElement",
        "DisplayObject",
        "EaselJS",
        "Event",
        "EventDispatcher",
        "Filter",
        "Graphics",
        "Log",
        "Matrix2D",
        "MouseEvent",
        "MovieClip",
        "MovieClipPlugin",
        "Point",
        "Rectangle",
        "Shadow",
        "Shape",
        "Sprite",
        "SpriteSheet",
        "SpriteSheetBuilder",
        "SpriteSheetUtils",
        "Stage",
        "Text",
        "Ticker",
        "Touch",
        "UID"
    ],
    "modules": [
        "EaselJS"
    ],
    "allModules": [
        {
            "displayName": "EaselJS",
            "name": "EaselJS"
        }
    ]
} };
});